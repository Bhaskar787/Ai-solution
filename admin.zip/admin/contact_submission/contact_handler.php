<?php
// Include database connection
require_once '../db_connection.php';

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../contact.php?error=invalid_request');
    exit;
}

// Get POST data and sanitize
$fullName = isset($_POST['fullName']) ? trim($_POST['fullName']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$company = isset($_POST['company']) ? trim($_POST['company']) : '';
$country = isset($_POST['country']) ? trim($_POST['country']) : '';
$jobTitle = isset($_POST['jobTitle']) ? trim($_POST['jobTitle']) : '';
$jobDetails = isset($_POST['jobDetails']) ? trim($_POST['jobDetails']) : '';

// Validate required fields
if (empty($fullName) || empty($email) || empty($phone) || empty($company) || empty($country) || empty($jobTitle) || empty($jobDetails)) {
    header('Location: ../contact.php?error=missing_fields');
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ../contact.php?error=invalid_email');
    exit;
}

// Get database connection
$link = get_db_connection();

// Prepare statement to prevent SQL injection
$stmt = mysqli_prepare($link, "INSERT INTO contact_submissions (full_name, email, phone, company, country, job_title, job_details) VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    header('Location: ../contact.php?error=db_error');
    exit;
}

// Bind parameters and execute
mysqli_stmt_bind_param($stmt, "sssssss", $fullName, $email, $phone, $company, $country, $jobTitle, $jobDetails);

if (mysqli_stmt_execute($stmt)) {
    // Success - redirect with success message
    header('Location: ../contact.php?success=1');
} else {
    // Error - redirect with error message
    header('Location: ../contact.php?error=submit_failed');
}

// Close statement and connection
mysqli_stmt_close($stmt);
mysqli_close($link);
?>

<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login/admin-login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reports | AI-Solutions Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .dashboard-bg {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(226, 232, 240, 0.8);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.1);
            transform: translateY(-1px);
        }
        
        .report-nav {
            position: sticky;
            top: 2rem;
            height: fit-content;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            border-radius: 0.5rem;
            color: #6b7280;
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .nav-item:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .nav-item.active {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            color: white;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .nav-item svg {
            width: 1.25rem;
            height: 1.25rem;
            margin-right: 0.75rem;
        }
        
        .report-section {
            display: none;
        }
        
        .report-section.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .stat-card {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 1rem;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transform: translate(30px, -30px);
        }
        
        .stat-card.users {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }
        
        .stat-card.revenue {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        }
        
        .stat-card.performance {
            background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        }
        
        .stat-card.security {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
        }
        
        .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin: 1rem 0;
        }
        
        .chart-container.large {
            height: 400px;
        }
        
        .table-container {
            overflow-x: auto;
            border-radius: 0.5rem;
            border: 1px solid #e5e7eb;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th {
            background: #f9fafb;
            padding: 0.75rem 1rem;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .data-table td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid #f3f4f6;
        }
        
        .data-table tr:hover {
            background: #f9fafb;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-completed {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .progress-bar {
            width: 100%;
            height: 0.5rem;
            background: #f3f4f6;
            border-radius: 0.25rem;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            transition: width 0.3s ease;
        }
        
        .filter-group {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        
        .form-input, .form-select {
            padding: 0.5rem 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            transition: all 0.2s ease;
        }
        
        .form-input:focus, .form-select:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .metric-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            padding: 1rem;
            text-align: center;
        }
        
        .metric-value {
            font-size: 1.875rem;
            font-weight: 700;
            color: #1f2937;
        }
        
        .metric-label {
            font-size: 0.875rem;
            color: #6b7280;
            margin-top: 0.25rem;
        }
        
        .metric-change {
            font-size: 0.75rem;
            font-weight: 500;
            margin-top: 0.25rem;
        }
        
        .metric-change.positive {
            color: #059669;
        }
        
        .metric-change.negative {
            color: #dc2626;
        }
        
        .notification {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1000;
            padding: 1rem 1.5rem;
            border-radius: 0.75rem;
            color: white;
            font-weight: 500;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .notification.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        
        .notification.info {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        
        .export-options {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.1);
            z-index: 10;
            min-width: 150px;
        }
        
        .export-options.show {
            display: block;
        }
        
        .export-option {
            display: block;
            padding: 0.75rem 1rem;
            color: #374151;
            text-decoration: none;
            transition: background 0.2s ease;
        }
        
        .export-option:hover {
            background: #f3f4f6;
        }
        
        .date-range-picker {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .activity-timeline {
            position: relative;
            padding-left: 2rem;
        }
        
        .activity-timeline::before {
            content: '';
            position: absolute;
            left: 0.75rem;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e5e7eb;
        }
        
        .activity-item {
            position: relative;
            margin-bottom: 1.5rem;
        }
        
        .activity-item::before {
            content: '';
            position: absolute;
            left: -1.75rem;
            top: 0.5rem;
            width: 0.75rem;
            height: 0.75rem;
            background: #3b82f6;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 0 0 2px #3b82f6;
        }
        
        .activity-content {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            padding: 1rem;
        }
    </style>
</head>
<body class="dashboard-bg">
    <!-- Notification -->
    <div id="notification" class="notification">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
        <span id="notification-text"></span>
    </div>

    <div class="min-h-screen p-6">
        <!-- Header -->
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-900 mb-2">Admin Reports</h1>
                <p class="text-gray-600">Comprehensive analytics and system insights</p>
            </div>
            <div class="flex items-center space-x-4 mt-4 lg:mt-0">
                <div class="date-range-picker">
                    <input type="date" class="form-input" id="start-date" value="2024-01-01">
                    <span class="text-gray-500">to</span>
                    <input type="date" class="form-input" id="end-date" value="2024-01-15">
                </div>
                <div class="relative">
                    <button id="export-btn" class="btn btn-success">
                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                        </svg>
                        Export Report
                    </button>
                    <div id="export-options" class="export-options">
                        <a href="#" class="export-option" data-format="pdf">Export as PDF</a>
                        <a href="#" class="export-option" data-format="excel">Export as Excel</a>
                        <a href="#" class="export-option" data-format="csv">Export as CSV</a>
                    </div>
                </div>
                <button id="refresh-btn" class="btn btn-secondary">
                    <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
                    </svg>
                    Refresh Data
                </button>
            </div>
        </div>

        <!-- Key Metrics Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="stat-card">
                <div class="relative z-10">
                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-white/80 text-sm font-medium">Total Users</h3>
                        <svg class="w-6 h-6 text-white/60" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M16 7c0-2.21-1.79-4-4-4S8 4.79 8 7s1.79 4 4 4 4-1.79 4-4zm-4 7c-2.67 0-8 1.34-8 4v3h16v-3c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                    <p class="text-3xl font-bold text-white" id="total-users-count">1,247</p>
                    <p class="text-white/70 text-sm mt-1" id="total-users-change">+12% from last month</p>
                </div>
            </div>

            <div class="stat-card users">
                <div class="relative z-10">
                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-white/80 text-sm font-medium">Active Sessions</h3>
                        <svg class="w-6 h-6 text-white/60" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                    </div>
                    <p class="text-3xl font-bold text-white" id="active-sessions-count">342</p>
                    <p class="text-white/70 text-sm mt-1" id="active-sessions-text">Currently online</p>
                </div>
            </div>

            <div class="stat-card revenue">
                <div class="relative z-10">
                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-white/80 text-sm font-medium">Inquiries</h3>
                        <svg class="w-6 h-6 text-white/60" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                        </svg>
                    </div>
                    <p class="text-3xl font-bold text-white" id="inquiries-count">89</p>
                    <p class="text-white/70 text-sm mt-1" id="inquiries-text">This month</p>
                </div>
            </div>

            <div class="stat-card performance">
                <div class="relative z-10">
                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-white/80 text-sm font-medium">System Health</h3>
                        <svg class="w-6 h-6 text-white/60" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M10,17L6,13L7.41,11.59L10,14.17L16.59,7.58L18,9L10,17Z"/>
                        </svg>
                    </div>
                    <p class="text-3xl font-bold text-white" id="system-health-percent">98.5%</p>
                    <p class="text-white/70 text-sm mt-1" id="system-health-text">Uptime this month</p>
                </div>
            </div>
        </div>

        <div class="grid lg:grid-cols-4 gap-8">
            <!-- Reports Navigation -->
            <div class="lg:col-span-1">
                <div class="card p-6 report-nav">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Reports</h3>
                    <nav class="space-y-1">
                        <a class="nav-item active" data-section="overview">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/>
                            </svg>
                            Overview
                        </a>
                        <a class="nav-item" data-section="users">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M16 7c0-2.21-1.79-4-4-4S8 4.79 8 7s1.79 4 4 4 4-1.79 4-4zm-4 7c-2.67 0-8 1.34-8 4v3h16v-3c0-2.66-5.33-4-8-4z"/>
                            </svg>
                            User Analytics
                        </a>
                        <a class="nav-item" data-section="inquiries">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                            </svg>
                            Inquiry Reports
                        </a>
                        <a class="nav-item" data-section="performance">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/>
                            </svg>
                            Performance
                        </a>
                        <a class="nav-item" data-section="security">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M10,17L6,13L7.41,11.59L10,14.17L16.59,7.58L18,9L10,17Z"/>
                            </svg>
                            Security
                        </a>
                        <a class="nav-item" data-section="activity">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                            </svg>
                            Activity Logs
                        </a>
                        <a class="nav-item" data-section="custom">
                            <svg fill="currentColor" viewBox="0 0 24 24">
                                <path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.07-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.74,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.07,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.47-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/>
                            </svg>
                            Custom Reports
                        </a>
                    </nav>
                </div>
            </div>

            <!-- Reports Content -->
            <div class="lg:col-span-3">
                <!-- Overview Report -->
                <div id="overview-section" class="report-section active">
                    <div class="card p-8 mb-6">
                        <h2 class="text-2xl font-bold text-gray-900 mb-6">System Overview</h2>
                        
                        <div class="grid md:grid-cols-2 gap-8">
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-4">User Growth</h3>
                                <div class="chart-container">
                                    <canvas id="userGrowthChart"></canvas>
                                </div>
                            </div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-4">Inquiry Trends</h3>
                                <div class="chart-container">
                                    <canvas id="inquiryTrendsChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid md:grid-cols-3 gap-6 mb-6">
                        <div class="metric-card">
                            <div class="metric-value" id="new-users-today">24</div>
                            <div class="metric-label">New Users Today</div>
                            <div class="metric-change positive" id="new-users-change">+15.3%</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="active-sessions-metric">156</div>
                            <div class="metric-label">Active Sessions</div>
                            <div class="metric-change positive" id="active-sessions-change">+8.7%</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="new-inquiries-metric">12</div>
                            <div class="metric-label">New Inquiries</div>
                            <div class="metric-change negative" id="new-inquiries-change">-2.1%</div>
                        </div>
                    </div>

                    <div class="card p-8">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">System Performance</h3>
                        <div class="chart-container large">
                            <canvas id="performanceChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- User Analytics -->
                <div id="users-section" class="report-section">
                    <div class="card p-8 mb-6">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-2xl font-bold text-gray-900">User Analytics</h2>
                            <div class="filter-group">
                                <select class="form-select">
                                    <option>All Users</option>
                                    <option>Active Users</option>
                                    <option>New Users</option>
                                    <option>Inactive Users</option>
                                </select>
                                <select class="form-select">
                                    <option>Last 7 days</option>
                                    <option>Last 30 days</option>
                                    <option>Last 90 days</option>
                                    <option>Custom Range</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid md:grid-cols-2 gap-8 mb-8">
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-4">User Registration</h3>
                                <div class="chart-container">
                                    <canvas id="userRegistrationChart"></canvas>
                                </div>
                            </div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-4">User Activity</h3>
                                <div class="chart-container">
                                    <canvas id="userActivityChart"></canvas>
                                </div>
                            </div>
                        </div>

                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Registration Date</th>
                                        <th>Last Login</th>
                                        <th>Status</th>
                                        <th>Inquiries</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="user-analytics-table">
                                    <!-- User data will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Inquiry Reports -->
                <div id="inquiries-section" class="report-section">
                    <div class="card p-8 mb-6">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-2xl font-bold text-gray-900">Inquiry Reports</h2>
                            <div class="filter-group">
                                <select class="form-select">
                                    <option>All Inquiries</option>
                                    <option>Pending</option>
                                    <option>In Progress</option>
                                    <option>Completed

<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Include database connection
require_once '../db_connection.php';

// Get database connection
$conn = get_db_connection();

// Get user statistics
function getUserStats($conn) {
    $stats = [];
    
    // Total users
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM admin_users");
    $row = mysqli_fetch_assoc($result);
    $stats['total_users'] = $row['total'];
    
    // Active users (assuming users who logged in within last 30 days)
    $result = mysqli_query($conn, "SELECT COUNT(*) as active FROM admin_users WHERE last_login > DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $row = mysqli_fetch_assoc($result);
    $stats['active_users'] = $row['active'];
    
    // New users today
    $result = mysqli_query($conn, "SELECT COUNT(*) as new_today FROM admin_users WHERE DATE(created_at) = CURDATE()");
    $row = mysqli_fetch_assoc($result);
    $stats['new_users_today'] = $row['new_today'];
    
    return $stats;
}

// Get user growth data
function getUserGrowthData($conn) {
    $data = [];
    
    // Get user count for last 4 weeks
    $result = mysqli_query($conn, "
        SELECT 
            DATE(created_at) as date,
            COUNT(*) as count
        FROM admin_users 
        WHERE created_at > DATE_SUB(NOW(), INTERVAL 4 WEEK)
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at)
    ");
    
    $dates = [];
    $counts = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $dates[] = $row['date'];
        $counts[] = (int)$row['count'];
    }
    
    return [
        'dates' => $dates,
        'counts' => $counts
    ];
}

// Get user activity data
function getUserActivityData($conn) {
    $data = [];
    
    // Get active users for last 7 days
    $result = mysqli_query($conn, "
        SELECT 
            DAYNAME(created_at) as day,
            COUNT(*) as count
        FROM admin_users 
        WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DAYNAME(created_at)
        ORDER BY DAYOFWEEK(created_at)
    ");
    
    $days = [];
    $counts = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $days[] = $row['day'];
        $counts[] = (int)$row['count'];
    }
    
    return [
        'days' => $days,
        'counts' => $counts
    ];
}

// Get user registration data
function getUserRegistrationData($conn) {
    $data = [];
    
    // Get registration counts for this week, last week, and previous
    $result = mysqli_query($conn, "
        SELECT 
            CASE 
                WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 'This Week'
                WHEN created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) THEN 'Last Week'
                ELSE 'Previous'
            END as period,
            COUNT(*) as count
        FROM admin_users 
        GROUP BY 
            CASE 
                WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 'This Week'
                WHEN created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) THEN 'Last Week'
                ELSE 'Previous'
            END
    ");
    
    $periods = [];
    $counts = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $periods[] = $row['period'];
        $counts[] = (int)$row['count'];
    }
    
    return [
        'periods' => $periods,
        'counts' => $counts
    ];
}

// Get user table data
function getUserTableData($conn) {
    $data = [];
    
    // Get user details
    $result = mysqli_query($conn, "
        SELECT 
            id,
            username,
            email,
            created_at as registration_date,
            last_login,
            CASE 
                WHEN last_login > DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 'Active'
                WHEN last_login > DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 'Inactive'
                ELSE 'Inactive'
            END as status
        FROM admin_users 
        ORDER BY created_at DESC
        LIMIT 10
    ");
    
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    
    return $data;
}

// Main execution
try {
    $response = [
        'stats' => getUserStats($conn),
        'growth_data' => getUserGrowthData($conn),
        'activity_data' => getUserActivityData($conn),
        'registration_data' => getUserRegistrationData($conn),
        'table_data' => getUserTableData($conn)
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>

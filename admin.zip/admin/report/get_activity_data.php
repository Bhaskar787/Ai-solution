<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Include database connection
require_once '../db_connection.php';

// Get database connection
$conn = get_db_connection();

// Get activity logs
function getActivityLogs($conn, $limit = 10) {
    $logs = [];
    
    // Get recent activity from contact submissions
    $result = mysqli_query($conn, "
        SELECT 
            'New Inquiry Submitted' as activity_type,
            CONCAT('Inquiry #', id, ' submitted by ', email) as description,
            created_at as timestamp
        FROM contact_submissions 
        ORDER BY created_at DESC
        LIMIT 5
    ");
    
    while ($row = mysqli_fetch_assoc($result)) {
        $logs[] = $row;
    }
    
    // Get recent user activities
    $result = mysqli_query($conn, "
        SELECT 
            'User Login' as activity_type,
            CONCAT(email, ' logged in') as description,
            last_login as timestamp
        FROM admin_users 
        WHERE last_login IS NOT NULL
        ORDER BY last_login DESC
        LIMIT 3
    ");
    
    while ($row = mysqli_fetch_assoc($result)) {
        $logs[] = $row;
    }
    
    // Add some system events
    $system_events = [
        [
            'activity_type' => 'System Backup',
            'description' => 'Daily backup completed successfully (2.4 GB)',
            'timestamp' => date('Y-m-d H:i:s', strtotime('-1 hour'))
        ],
        [
            'activity_type' => 'Settings Updated',
            'description' => 'Email notifications enabled by admin',
            'timestamp' => date('Y-m-d H:i:s', strtotime('-2 hours'))
        ],
        [
            'activity_type' => 'User Registration',
            'description' => 'New user registered',
            'timestamp' => date('Y-m-d H:i:s', strtotime('-3 hours'))
        ]
    ];
    
    // Merge system events with database events
    $logs = array_merge($logs, $system_events);
    
    // Sort by timestamp
    usort($logs, function($a, $b) {
        return strtotime($b['timestamp']) - strtotime($a['timestamp']);
    });
    
    // Limit to requested number
    return array_slice($logs, 0, $limit);
}

// Main execution
try {
    $response = [
        'activity_logs' => getActivityLogs($conn)
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>

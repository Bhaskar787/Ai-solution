<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Include database connection
require_once '../db_connection.php';

// Get database connection
$conn = get_db_connection();

// Get performance statistics
function getPerformanceStats($conn) {
    $stats = [];
    
    // System uptime (simulated)
    $stats['uptime'] = '98.5%';
    
    // Average response time (simulated)
    $stats['avg_response_time'] = '1.2s';
    
    // Memory usage (simulated)
    $stats['memory_usage'] = '2.4GB';
    
    // CPU usage (simulated)
    $stats['cpu_usage'] = '45%';
    
    return $stats;
}

// Get server response time data
function getServerResponseData($conn) {
    $data = [];
    
    // Simulated server response times for different hours
    $hours = ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'];
    $response_times = [850, 920, 1100, 1350, 1200, 980, 890]; // in milliseconds
    
    return [
        'hours' => $hours,
        'response_times' => $response_times
    ];
}

// Get resource usage data
function getResourceUsageData($conn) {
    $data = [];
    
    // Simulated resource usage percentages
    $resources = ['CPU', 'Memory', 'Disk', 'Network', 'Database'];
    $usage = [45, 65, 30, 25, 55];
    
    return [
        'resources' => $resources,
        'usage' => $usage
    ];
}

// Get performance metrics
function getPerformanceMetrics($conn) {
    $metrics = [];
    
    // Database performance
    $metrics['database_performance'] = 92;
    
    // API response rate
    $metrics['api_response_rate'] = 98;
    
    // Cache hit rate
    $metrics['cache_hit_rate'] = 85;
    
    return $metrics;
}

// Main execution
try {
    $response = [
        'stats' => getPerformanceStats($conn),
        'server_response_data' => getServerResponseData($conn),
        'resource_usage_data' => getResourceUsageData($conn),
        'performance_metrics' => getPerformanceMetrics($conn)
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>

<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Include database connection
require_once '../db_connection.php';

// Get database connection
$conn = get_db_connection();

// Get security statistics
function getSecurityStats($conn) {
    $stats = [];
    
    // Failed logins (simulated)
    $stats['failed_logins'] = 12;
    
    // Security breaches
    $stats['security_breaches'] = 0;
    
    // Active sessions
    $stats['active_sessions'] = 156;
    
    // Security score
    $stats['security_score'] = 'A+';
    
    return $stats;
}

// Get login attempts data
function getLoginAttemptsData($conn) {
    $data = [];
    
    // Simulated login attempts for the last week
    $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    $successful = [145, 132, 158, 142, 167, 89, 76];
    $failed = [3, 2, 5, 1, 4, 8, 2];
    
    return [
        'days' => $days,
        'successful' => $successful,
        'failed' => $failed
    ];
}

// Get security events
function getSecurityEvents($conn) {
    $events = [];
    
    // Simulated security events
    $events[] = [
        'type' => 'Failed Login Attempt',
        'description' => 'IP: 203.0.113.1',
        'time' => '2 hours ago',
        'severity' => 'high'
    ];
    
    $events[] = [
        'type' => 'Suspicious Activity',
        'description' => 'Multiple login attempts',
        'time' => '5 hours ago',
        'severity' => 'medium'
    ];
    
    $events[] = [
        'type' => 'Security Update',
        'description' => 'System patched successfully',
        'time' => '1 day ago',
        'severity' => 'info'
    ];
    
    return $events;
}

// Main execution
try {
    $response = [
        'stats' => getSecurityStats($conn),
        'login_attempts_data' => getLoginAttemptsData($conn),
        'security_events' => getSecurityEvents($conn)
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>

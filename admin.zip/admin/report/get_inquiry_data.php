<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Include database connection
require_once '../db_connection.php';

// Get database connection
$conn = get_db_connection();

// Get inquiry statistics
function getInquiryStats($conn) {
    $stats = [];
    
    // Total inquiries
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM contact_submissions");
    $row = mysqli_fetch_assoc($result);
    $stats['total_inquiries'] = $row['total'];
    
    // Pending inquiries
    $result = mysqli_query($conn, "SELECT COUNT(*) as pending FROM contact_submissions WHERE status = 'New'");
    $row = mysqli_fetch_assoc($result);
    $stats['pending'] = $row['pending'];
    
    // In progress inquiries
    $result = mysqli_query($conn, "SELECT COUNT(*) as in_progress FROM contact_submissions WHERE status = 'In Progress'");
    $row = mysqli_fetch_assoc($result);
    $stats['in_progress'] = $row['in_progress'];
    
    // Completed inquiries
    $result = mysqli_query($conn, "SELECT COUNT(*) as completed FROM contact_submissions WHERE status = 'Completed'");
    $row = mysqli_fetch_assoc($result);
    $stats['completed'] = $row['completed'];
    
    return $stats;
}

// Get inquiry trends data
function getInquiryTrendsData($conn) {
    $data = [];
    
    // Get inquiry count for last 4 weeks
    $result = mysqli_query($conn, "
        SELECT 
            WEEK(created_at) as week,
            COUNT(*) as count
        FROM contact_submissions 
        WHERE created_at > DATE_SUB(NOW(), INTERVAL 4 WEEK)
        GROUP BY WEEK(created_at)
        ORDER BY WEEK(created_at)
    ");
    
    $weeks = [];
    $counts = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $weeks[] = 'Week ' . $row['week'];
        $counts[] = (int)$row['count'];
    }
    
    return [
        'weeks' => $weeks,
        'counts' => $counts
    ];
}

// Get inquiry status distribution
function getInquiryStatusData($conn) {
    $data = [];
    
    // Get status distribution
    $result = mysqli_query($conn, "
        SELECT 
            status,
            COUNT(*) as count
        FROM contact_submissions 
        GROUP BY status
    ");
    
    $statuses = [];
    $counts = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $statuses[] = $row['status'];
        $counts[] = (int)$row['count'];
    }
    
    return [
        'statuses' => $statuses,
        'counts' => $counts
    ];
}

// Get response time data
function getResponseTimeData($conn) {
    $data = [];
    
    // Get response time distribution
    $result = mysqli_query($conn, "
        SELECT 
            CASE 
                WHEN response_time < 1 THEN '< 1h'
                WHEN response_time < 4 THEN '1-4h'
                WHEN response_time < 24 THEN '4-24h'
                ELSE '> 24h'
            END as time_range,
            COUNT(*) as count
        FROM contact_submissions 
        WHERE response_time IS NOT NULL
        GROUP BY 
            CASE 
                WHEN response_time < 1 THEN '< 1h'
                WHEN response_time < 4 THEN '1-4h'
                WHEN response_time < 24 THEN '4-24h'
                ELSE '> 24h'
            END
    ");
    
    $time_ranges = [];
    $counts = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $time_ranges[] = $row['time_range'];
        $counts[] = (int)$row['count'];
    }
    
    return [
        'time_ranges' => $time_ranges,
        'counts' => $counts
    ];
}

// Get inquiry table data
function getInquiryTableData($conn) {
    $data = [];
    
    // Get inquiry details
    $result = mysqli_query($conn, "
        SELECT 
            id,
            name,
            email,
            subject,
            created_at as date,
            status,
            priority
        FROM contact_submissions 
        ORDER BY created_at DESC
        LIMIT 10
    ");
    
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    
    return $data;
}

// Main execution
try {
    $response = [
        'stats' => getInquiryStats($conn),
        'trends_data' => getInquiryTrendsData($conn),
        'status_data' => getInquiryStatusData($conn),
        'response_time_data' => getResponseTimeData($conn),
        'table_data' => getInquiryTableData($conn)
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>

<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../db_connection.php';

$link = get_db_connection();

$conversation_id = isset($_POST['conversation_id']) ? $_POST['conversation_id'] : '';

if (empty($conversation_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing conversation_id']);
    exit;
}

// Fetch messages
$stmt = mysqli_prepare($link, "SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC");
mysqli_stmt_bind_param($stmt, "s", $conversation_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$messages = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

// Mark messages as read
$stmt = mysqli_prepare($link, "UPDATE messages SET is_read = 1 WHERE conversation_id = ? AND sender_type = 'user'");
mysqli_stmt_bind_param($stmt, "s", $conversation_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

// Update unread count in conversations
$stmt = mysqli_prepare($link, "UPDATE conversations SET unread_count = 0 WHERE conversation_id = ?");
mysqli_stmt_bind_param($stmt, "s", $conversation_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

mysqli_close($link);

echo json_encode(['success' => true, 'messages' => $messages]);
?>

<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../db_connection.php';

$link = get_db_connection();

$conversation_id = isset($_POST['conversation_id']) ? $_POST['conversation_id'] : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

if (empty($conversation_id) || empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Get user email from conversations table
$stmt = mysqli_prepare($link, "SELECT user_email FROM conversations WHERE conversation_id = ?");
mysqli_stmt_bind_param($stmt, "s", $conversation_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
$user_email = $row['user_email'];
mysqli_stmt_close($stmt);

if (!$user_email) {
    echo json_encode(['success' => false, 'message' => 'Conversation not found']);
    exit;
}

// Send email using PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once '../../PHPMailer/src/Exception.php';
require_once '../../PHPMailer/src/PHPMailer.php';
require_once '../../PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'baddepartment434@gmail.com';
    $mail->Password = 'ihzqyttvdapipryj';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('baddepartment434@gmail.com', 'AI-Solutions Admin');
    $mail->addAddress($user_email);

    $mail->isHTML(false);
    $mail->Subject = 'Response from AI-Solutions Admin';
    $mail->Body = $message;

    $mail->send();
    $emailSent = true;
} catch (Exception $e) {
    $emailSent = false;
    error_log("Email sending failed: " . $mail->ErrorInfo);
}

if ($emailSent) {
    // Save message in DB
    $sender_type = 'admin';
    $attachment = NULL;
    $created_at = date('Y-m-d H:i:s');

    $stmt = mysqli_prepare($link, "INSERT INTO messages (conversation_id, sender_type, message, attachment, is_read, created_at) VALUES (?, ?, ?, ?, 1, ?)");
    mysqli_stmt_bind_param($stmt, "sssss", $conversation_id, $sender_type, $message, $attachment, $created_at);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Update conversations table
    $stmt = mysqli_prepare($link, "UPDATE conversations SET last_message = ?, last_message_time = ? WHERE conversation_id = ?");
    mysqli_stmt_bind_param($stmt, "sss", $message, $created_at, $conversation_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    mysqli_close($link);
    echo json_encode(['success' => true, 'message' => 'Reply sent successfully']);
} else {
    mysqli_close($link);
    echo json_encode(['success' => false, 'message' => 'Failed to send email']);
}
?>
